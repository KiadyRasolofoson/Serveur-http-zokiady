#!/bin/bash

# Définir les chemins d'installation
INSTALL_DIR="/opt/zokiady-server"
BIN_DIR="/usr/local/bin"
SRC_DIR="./zokiady-server/src/com/monserveur"  # Répertoire contenant les fichiers .java
BIN_OUTPUT="/opt/zokiady-server/src/com/monserveur"  # Répertoire pour les fichiers compilés
JAR_FILE="zokiady-server.jar"

# Vérification des prérequis
echo "Vérification de Java..."
JAVA_PATH=$(which java)
JAVAC_PATH=$(which javac)
if [[ -z "$JAVA_PATH" || -z "$JAVAC_PATH" ]]; then
  echo "Erreur : Les outils Java (java et javac) sont nécessaires. Installez-les avant de continuer."
  exit 1
fi

# Compilation des fichiers Java
echo "Compilation des fichiers Java..."
mkdir -p "$BIN_OUTPUT"
if ! "$JAVAC_PATH" -d "$BIN_OUTPUT" "$SRC_DIR"/*.java; then
  echo "Erreur lors de la compilation des fichiers Java."
  exit 1
fi


# Créer le répertoire d'installation
echo "Création du répertoire d'installation..."
sudo mkdir -p "$INSTALL_DIR"
sudo cp -r ./zokiady-server/* "$INSTALL_DIR"
sudo chmod +x ./zokiady-server/startServer.sh

# Ajouter un fichier de configuration
echo "Création du fichier de configuration..."
echo $INSTALL_DIR
sudo mkdir -p "$INSTALL_DIR/conf"
sudo touch "$INSTALL_DIR/conf/Serveur.conf"
sudo chmod 777 "$INSTALL_DIR/conf/Serveur.conf"
echo "path=/opt/zokiady-server/htdocs/" >> "$INSTALL_DIR/conf/Serveur.conf"
echo "php=true" >> "$INSTALL_DIR/conf/Serveur.conf"
echo "port=8080" >> "$INSTALL_DIR/conf/Serveur.conf"
echo "rootPath=/opt/zokiady-server/" >> "$INSTALL_DIR/conf/Serveur.conf"

echo "Installation terminée !"
echo "Vous pouvez exécuter le projet avec la commande : zokiady-server"
