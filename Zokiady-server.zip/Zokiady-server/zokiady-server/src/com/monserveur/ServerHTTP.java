
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;



public class ServerHTTP {
    public static void main(String[] args) {
        Conf cf = new Conf();
        //int port = cf.port;
        int port = cf.port;
        String cheminFichierHTML = cf.path ;
        Log Access = new Log() ;
        Access.LOG_FILE("ACCESS");
        
        try(
            ServerSocket serverSocket = new ServerSocket(port);
            
        )
         {
            System.out.println("Serveur HTTP démaré sur le port :"+port);

            while (true) {
                Socket clientSocket = null;
                try {
                    // Accepter une connexion client
                    clientSocket = serverSocket.accept();
                    Access.AjouterAccess("Nouvelle connexion client " + clientSocket.getInetAddress());
                    System.out.println("Nouvelle connexion client : " + clientSocket.getInetAddress());
            
                    BufferedReader brClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    String requete = brClient.readLine();
            
                    if (requete == null) {
                        System.out.println("Requête null reçue. Connexion fermée par le client.");
                        continue;
                    }
            
                    System.out.println("REQUETE : " + requete);
                    
                    // Gestion favicon.ico
                    if (requete.contains("GET /favicon.ico")) {
                        String response = "HTTP/1.1 204 No Content\r\n\r\n";
                        clientSocket.getOutputStream().write(response.getBytes());
                        continue;
                    }
                    String[] tab = requete.split(" ");
                    String methode = tab[0];
                    
                    // Extraire le chemin du fichier
                     cheminFichierHTML = extraireChemin(requete, cf.path);
                     System.err.println("CHEMINHTML :"+cheminFichierHTML);
                    Access.AjouterAccess("Le client :"+clientSocket.getInetAddress().getHostName() +" a ouvert le fichier :"+cheminFichierHTML);
                    // Lire ou exécuter le fichier demandé
                    String contenuPage;
                    if (cheminFichierHTML.endsWith(".php")) {
                        if ("POST".equalsIgnoreCase(methode)) {
                            // Lire les données POST
                            int contentLength = getContentLength(brClient);
                            System.err.println("CONTENTLENGHT :"+contentLength);
                            String postData = readPostData(brClient, contentLength);
                            System.out.println("Données POST reçues : " + postData);
                            contenuPage = executePHP(cheminFichierHTML , requete, postData, "POST");
                        } else {
                            contenuPage = executePHP(cheminFichierHTML, requete, null, "GET");
                        }
                    } else {
                        contenuPage = LireFichierHTML(cheminFichierHTML);
                    }
            
                    // Construire et envoyer la réponse HTTP
                    String response = "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/html; charset=UTF-8\r\n\r\n" + contenuPage;
                    clientSocket.getOutputStream().write(response.getBytes());
            
                } catch (IOException e) {
                    System.err.println("Erreur : " + e.getMessage());
                    Log err = new Log();
                    err.LOG_FILE("ERROR");
                    err.AjouterError("Erreur : " + e.getMessage());
            
                    try {
                        if (clientSocket != null && !clientSocket.isClosed()) {
                            String response = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
                            clientSocket.getOutputStream().write(response.getBytes());
                        }
                    } catch (IOException ex) {
                        System.err.println("Erreur lors de l'envoi de la réponse d'erreur : " + ex.getMessage());
                        Access.AjouterError("Erreur lors de l'envoi de la réponse d'erreur : "+e.getMessage());
                    }
            
                } finally {
                    try {
                        if (clientSocket != null) {
                            clientSocket.close();
                            Access.AjouterAccess("Déconnexion du client: " + clientSocket.getInetAddress().getHostName());
                        }
                    } catch (IOException e) {
                        System.err.println("Erreur lors de la fermeture du socket client : " + e.getMessage());
                        Access.AjouterError("Erreur lors de la fermeture du socket client : "+e.getMessage());
                    }
                }
            }
            
        } catch (IOException e) {
            System.err.println("Erreur du serveur :"+e.getMessage());
            Log err = new Log();
            err.LOG_FILE("ERROR");
            err.AjouterError("Erreur du serveur : "+e.getMessage()+".");
        }
        
    }
    
    public static String LireFichierHTML(String chemin) throws IOException {{
        StringBuilder html = new StringBuilder();
        try(BufferedReader reader = new BufferedReader(new FileReader(chemin))){
            String ligne ; 
            while ((ligne=reader.readLine())!=null) {
                html.append(ligne).append("\n");
            }
        }
        return html.toString() ;
    }
}public static String executePHP(String chemin, String requete , String postData,String methode) {
    StringBuilder sb = new StringBuilder();
    Log err = new Log() ;
    err.LOG_FILE("ERROR");
    Log Access = new Log();
    Access.LOG_FILE("ACCESS");
    try {
        String params = null;
        
        // Extraire les paramètres GET de la requête HTTP
        if (requete != null) {
            String[] tab = requete.split(" ");
            if (tab.length >= 2) {
                String[] tab2 = tab[1].split("\\?");
                if (tab2.length >= 2) {
                    // Extraction des paramètres GET (tout après '?')
                    params = tab2[1];
                }
            }
        }

       
        
        // Séparer le fichier PHP et les paramètres GET
        String[] cheminSplit = chemin.split("\\?");
        String fichier = cheminSplit[0]; // Le fichier PHP sans les paramètres
        
        
        // Vérifier si le fichier existe
        java.nio.file.Path path = java.nio.file.Paths.get(fichier);
        if (!java.nio.file.Files.exists(path)) {
            sb.append("<html><body><h1>Erreur 404</h1><p>Fichier non trouvé.</p></body></html>");
            err.AjouterError("Le fichier :"+path+" est introuvable .");
            return sb.toString();
        }

        
        // Lire le contenu de test2.php et ajouter le code nécessaire sans altérer les balises existantes
        StringBuilder phpScript = new StringBuilder();
         boolean cliParseAlreadyAdded = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(fichier))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("LINE :"+line);
                phpScript.append(line).append("\n");
                if (line.contains("php_sapi_name() === 'cli'")) {
                    cliParseAlreadyAdded = true ;
                }
            }
        }


       if (!cliParseAlreadyAdded) {
         // Si le fichier PHP commence par "<?php", on n'ajoute pas une nouvelle balise PHP
         if (phpScript.indexOf("<?php") == -1) {
            // Ajouter le code PHP pour traiter les paramètres GET si en mode CLI
            phpScript.insert(0, "<?php\nif (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); } ?>\n");
        } else {
            // Si le fichier contient déjà des balises PHP, insérer juste la ligne de traitement
            phpScript.insert(phpScript.indexOf("<?php") + 5, "\nif (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); }\n");
        }
        
        // Réécrire le fichier test2.php avec le contenu modifié
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fichier))) {
            writer.write(phpScript.toString());
        }
        
       }

        // Créer le processus pour exécuter le fichier PHP avec le paramètre QUERY_STRING
        ProcessBuilder builder = new ProcessBuilder("php", "-d", "variables_order=EGPCS", fichier);
       if (params==null) {
            err.AjouterError("Les parametres "+params+" sont/est introuvable(s) .");
       }
        // Si des paramètres GET existent, les passer à l'environnement
        
        if (methode=="GET") {
            if (params != null && !params.isEmpty()) {
                Access.AjouterAccess("Les paramètres GET sont :"+params);
                builder.environment().put("QUERY_STRING", params);  // Passer les paramètres GET à PHP via l'environnement
                builder.environment().put("REQUEST_METHOD", "GET");
                builder.environment().put("REDIRECT_STATUS", "200");
            }
        }
        File scriptFile = new File(fichier);
         if (methode=="POST") {
            if (postData!= null && !postData.isEmpty()) {
                Access.AjouterAccess("Les paramètres POST sont :"+postData);
                System.out.println("POST DATA :"+postData.getBytes());
                 builder = new ProcessBuilder("php", fichier);
                builder.redirectErrorStream(true);
                builder.environment().put("SCRIPT_NAME", fichier);
                builder.environment().put("REQUEST_METHOD", "POST");
                builder.environment().put("CONTENT_TYPE", "application/x-www-form-urlencoded");
                builder.environment().put("CONTENT_LENGTH", String.valueOf(postData.length()));
                builder.environment().put("DOCUMENT_ROOT", scriptFile.getParent());
                builder.environment().put("REDIRECT_STATUS", "2");
                
Process process = builder.start();


try (OutputStream os = process.getOutputStream()) {
    os.write(postData.getBytes(StandardCharsets.UTF_8));
   
    os.flush();
}
            
            

BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
String line;
while ((line = reader.readLine()) != null) {
    System.out.println(line);
}
            }
        }

        // Vérifier que QUERY_STRING est bien passée
        System.out.println("QUERY_STRING (Java) : " + builder.environment().get("QUERY_STRING"));
    
        builder.redirectErrorStream(true); // Rediriger les erreurs vers la sortie standard
        Process process = builder.start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

        // Lire la sortie du processus PHP
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }

        process.waitFor(); // Attendre la fin de l'exécution de PHP

    } catch (Exception e) {
        sb.append("<html><body><h1>Erreur PHP</h1><p>").append(e.getMessage()).append("</p></body></html>");
        err.AjouterError(e.getMessage());
        
    }

    return sb.toString();
}


public static String extraireChemin(String requete, String chemin) {
    chemin = chemin ;
    if (requete != null) {
        String[] tab = requete.split(" ");
        
        if (tab.length >= 2) {
            String[] tab2 = tab[1].split("\\?");
            if (tab2.length >= 2) {
                // Extraction des paramètres GET
                String params = tab2[1];
                System.out.println("Paramètres GET : " + params);
                
                // Assurer que le chemin de base se termine par "/"
                if (!chemin.endsWith("/")) {
                    chemin += "/";
                }
                chemin += tab2[0]; // Chemin sans les paramètres
                return chemin; // Retourne chemin complet avec paramètres
            } else {
                if (tab[1].length() == 1) {
                    chemin += "list_files.php";
                } else if (tab[1].equals("/favicon.ico")) {
                    // Pas de modification du chemin pour le favicon
                    chemin = chemin;
                } else {
                    // Assurer que le chemin de base se termine par "/"
                    if (!chemin.endsWith("/")) {
                        chemin += "/";
                    }
                    chemin += tab[1]; // Ajouter le fichier à la fin du chemin
                }
                return chemin;
            }
        }
    }
    return chemin + "hh"; // Retourner un chemin par défaut en cas d'erreur
}

public static int getContentLength(BufferedReader brClient) throws IOException {
    int contentLength = 0;
    String line;
    while (!(line = brClient.readLine()).isEmpty()) {
        if (line.startsWith("Content-Length:")) {
            contentLength = Integer.parseInt(line.split(":")[1].trim());
        }
    }
    return contentLength;
}

public static String readPostData(BufferedReader brClient, int contentLength) throws IOException {
    char[] buffer = new char[contentLength];
    brClient.read(buffer, 0, contentLength);
    return new String(buffer);
}


}
