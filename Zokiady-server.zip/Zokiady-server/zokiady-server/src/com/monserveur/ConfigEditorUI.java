
import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ConfigEditorUI {
    private ConfigManager configManager;

    public ConfigEditorUI(String configFilePath) {
        Log Error = new Log();
        Error.LOG_FILE("ERROR");
        try {
            configManager = new ConfigManager(configFilePath);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Erreur de chargement du fichier de configuration : " + e.getMessage());
            Error.AjouterAccess("Erreur de chargement du fichier de configuration : "+e.getMessage());
            return;
        }

        // Créer la fenêtre principale
        JFrame frame = new JFrame("Éditeur de Configuration");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(5, 2));

        // Champs pour chaque propriété
        JLabel portLabel = new JLabel("Port:");
        JTextField portField = new JTextField(configManager.getProperty("port"));

        JLabel pathLabel = new JLabel("Path:");
        JTextField pathField = new JTextField(configManager.getProperty("path"));

        JCheckBox phpField = new JCheckBox("Activer php");

        JButton saveButton = new JButton("Enregistrer");

        // Ajouter les composants à la fenêtre
        frame.add(portLabel);
        frame.add(portField);

        frame.add(pathLabel);
        frame.add(pathField);

        frame.add(phpField);

        frame.add(new JLabel()); // Espace vide
        frame.add(saveButton);

        // Action pour le bouton "Enregistrer"
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Log Access = new Log();
                Log Error = new Log();
                Error.LOG_FILE("ERROR");
                Access.LOG_FILE("ACCESS");
                try {
                    configManager.setProperty("port", portField.getText());
                    configManager.setProperty("path", pathField.getText());
                    if(phpField.isSelected()){
                        configManager.setProperty("php", "true");
                    }else{
                        configManager.setProperty("php", "false");
                    }
                    JOptionPane.showMessageDialog(frame, "Configuration enregistrée avec succès !");
                    Access.AjouterAccess("Après configurations le port est : " + portField.getText()+".\n Le path est :"+pathField.getText()+" et le php est : "+phpField.getText());

                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame, "Erreur lors de l'enregistrement : " + ex.getMessage());
                    Error.AjouterAccess("Erreur l'enregistrement : " + ex.getMessage());
                }
            }
        });

        // Afficher la fenêtre
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConfigEditorUI("/home/zo/Documents/ProgSys1/prog6/Serveur.conf"));
    }
}
