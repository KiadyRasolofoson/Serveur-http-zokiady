
public class Main {
    public static void main(String[] args) {
        ServerControl sc = new ServerControl();
        sc.Start();
    }
}
