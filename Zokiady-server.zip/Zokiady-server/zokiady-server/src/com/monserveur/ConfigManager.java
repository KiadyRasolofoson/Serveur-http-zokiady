
import java.io.*;
import java.util.Properties;

public class ConfigManager {
    private Properties properties;
    private String filePath;

    public ConfigManager(String filePath) throws IOException {
        this.filePath = filePath;
        properties = new Properties();
        try (FileReader reader = new FileReader(filePath)) {
            properties.load(reader);
        }
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public void setProperty(String key, String value) throws IOException {
        properties.setProperty(key, value);
        try (FileWriter writer = new FileWriter(filePath)) {
            properties.store(writer, "Updated configuration");
        }
    }

}
