
import java.io.*;
import java.util.ArrayList;

public class Conf{
    public int port = 8080;
    public String path;
    private String rootPath;
    public Conf(){
        try (BufferedReader br = new BufferedReader(new FileReader("/opt/zokiady-server/conf/Serveur.conf"))){
            String line;
   
            while ((line = br.readLine()) != null) {
                String[] values = line.split("=");
                if(values[0].equals("port")){
                    this.port = Integer.parseInt(values[1]);
                }else if (values[0].equals("path")){
                    this.path=values[1];
                }else if (values[0].equals("rootPath")){
                    this.rootPath=values[1];
                }
            }
        }catch (IOException e){
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }
    }
    public String getRootPath(){
        return this.rootPath;
    }
}