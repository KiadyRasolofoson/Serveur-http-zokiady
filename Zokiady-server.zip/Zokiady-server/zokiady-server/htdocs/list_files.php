<?php
if (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); }
$config = parse_ini_file("../conf/Serveur.conf");
$phpValue=$config['php'];
$directory = "./htdocs";
$d="";
$retour=$directory;
if( isset($_GET["dir"])){
    $directory = $directory."/".$_GET["dir"];
    $d=$_GET["dir"];
    $retour=$d;
}
if( isset($_GET["back"])){
    $directory="./htdocs";
}

function listFilesAndDirectories($directory) {
    $files = scandir($directory);

    // Filtrer les fichiers pour ne garder que les html, php et txt
    if($phpValue){
        $allowedExtensions = ['html', 'php', 'txt'];
    }else{
        $allowedExtensions = ['html', 'txt'];
    }
 
    $fileList = [];
    $directoryList = [];

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $path = $directory . DIRECTORY_SEPARATOR . $file;
        if (is_dir($path)) {
            $directoryList[] = $file;
        } elseif (is_file($path)) {
            $extension = pathinfo($file, PATHINFO_EXTENSION);
            if (in_array($extension, $allowedExtensions)) {
                $fileList[] = $file;
            }
        }
    }

    // Trier les dossiers et fichiers
    sort($directoryList);
    sort($fileList);

    return array_merge($directoryList, $fileList);
}

$items = listFilesAndDirectories($directory);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des fichiers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
            transition: background-color 0.3s;
        }

        ul li:hover {
            background-color: #eef;
        }

        ul li a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        ul li a:hover {
            text-decoration: underline;
        }

        .folder {
            color: #FF9800;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Liste des fichiers et dossiers</h1>
        <ul>
                <li class="folder">
                    <a href="list_files.php?back=1"  target="">
                        <?php echo "..."; ?>
                    </a>
                </li>
            <?php foreach ($items as $item): ?>
                <?php if(is_dir($directory . DIRECTORY_SEPARATOR . $item)){ ?>
                <li class="folder">
                    <a href="list_files.php?dir=<?php echo $item; ?>" target="">
                        <?php echo $item; ?>
                    </a>
                </li>
                <?php }else{ ?>
                <li class="file">
                    <a href="<?php 
                        if ($d!=null){
                            echo $d."/".$item;
                        }else{
                            echo $item;
                        }
                     ?>" target="_blank">
                        <?php echo $item; ?>
                    </a>
                </li>
                <?php }?>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
