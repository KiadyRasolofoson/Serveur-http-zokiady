<?php
if (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); } ?>
