<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
if (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); }

echo "Raw POST Data:\n";
echo file_get_contents('php://input');
echo "Content-Type: " . ($_SERVER['CONTENT_TYPE'] ?? 'Not Set') . "<br>";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<h2>POST Data Received:</h2>";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
} else {
    echo "No POST data received.";
}

    
        ?>
    Nom : <?php echo $_POST['name']; ?>
    Age : <?php echo $_POST['age'] +1; ?>

</html>
