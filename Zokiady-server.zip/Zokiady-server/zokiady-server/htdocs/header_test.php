<?php
if (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); }
 
    header('location:list_files.php?dir=null');
?>
