<?php
if (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); }

?>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Fichiers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            padding: 5px;
            border-bottom: 1px solid #ccc;
        }
    </style>
</head>
<body>
<form action="test2.php" method="POST">
    <input type="text" name="name" id="">
    <input type="number" name="age" id="">
    <input type="submit" value="">
    
</form>
</body>
</html>
