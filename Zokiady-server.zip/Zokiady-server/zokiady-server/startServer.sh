#!/bin/bash
cd /opt/zokiady-server/src/com/monserveur
java Main